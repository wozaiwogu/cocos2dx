var res = {
    HelloWorld_png : "res/HelloWorld.png",
    MainScene_json : "res/MainScene.json"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}
