
void package___PACKAGE_NAME___register()
{
}

