from project_new import CCPluginNew
